<?php $__env->startSection('title', app_name() . ' | ' . __('navs.general.home')); ?>


<?php $__env->startPush('after-styles'); ?>
    <link href="<?php echo e(url('css/import_and_installation.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

    <div class="container-fluid mt-3 py-5 px-0" style="background-color: #d2f1fc; color: #0b3f52;">
        <div class="container text-center">

            <div class="row justify-content-center">
                <div class="col-12">
                    <h1>Spice Processing Industry</h1>
                </div>
            </div>
        </div>

        <div class="mt-5">
            <img src="<?php echo e(url('images/import_installation/spice.jpg')); ?>" alt="" class="img-fluid w-100">
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Zajjith Vedha\Documents\Enspirer International\FoodTech\resources\views/frontend/food_processing/spice.blade.php ENDPATH**/ ?>