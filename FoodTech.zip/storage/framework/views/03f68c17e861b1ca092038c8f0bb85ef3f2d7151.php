<?php if (\Illuminate\Support\Facades\Blade::check('readonly')): ?>
    <div class="alert alert-info read-only">
        The Application is currently in read only mode. All requests other than GET are disabled.
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Zajjith Vedha\Documents\Enspirer International\Food Tech\resources\views/includes/partials/read-only.blade.php ENDPATH**/ ?>