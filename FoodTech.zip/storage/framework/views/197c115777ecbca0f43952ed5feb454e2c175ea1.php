<?php $__env->startSection('title', app_name() . ' | ' . __('navs.general.home')); ?>


<?php $__env->startPush('after-styles'); ?>
    <link href="<?php echo e(url('css/food.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

    <div class="container-fluid mt-3 py-5 px-0" style="background-color: #d2f1fc; color: #0b3f52;">
        <div class="container text-center">

            <div class="row justify-content-center">
                <div class="col-12">
                    <h1>Baking and Confectionery Industry</h1>
                </div>
            </div>
        </div>

        <div class="mt-5">
            <img src="<?php echo e(url('images/import_installation/baking.jpg')); ?>" alt="" class="img-fluid w-100">
        </div>

        <div class="container position-relative" style="top: -6rem;">
            <div class="row justify-content-center">
                <div class="col-10">
                    <img src="<?php echo e(url('images/import_installation/3.png')); ?>" alt="" class="img-fluid">
                </div>
            </div>
        </div>


        <div class="container">
            <div class="row justify-content-center">
                <div class="col-6">
                    <p style="text-align:justify;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure illo quibusdam nemo, dolore nobis nisi ab tempore rem error consectetur facere enim odio vero exercitationem eius ipsam autem, quam cumque laboriosam! Illum est, adipisci assumenda quo nisi cupiditate officia officiis nulla nemo architecto minus hic exercitationem, a doloremque quasi totam laborum explicabo tempora ex. Rem obcaecati eligendi perspiciatis maxime! Libero, consequuntur? Impedit nesciunt unde modi provident numquam iste quod, ullam id vitae praesentium officia quo culpa voluptate eveniet necessitatibus nisi expedita reprehenderit pariatur suscipit tempore. Possimus impedit officiis vel cum perferendis, consequatur recusandae aperiam cumque itaque obcaecati sequi cupiditate labore!</p>
                </div>
            </div>
        </div>

    </div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Zajjith Vedha\Documents\Enspirer International\FoodTech\resources\views/frontend/food_processing/baking_and_confectionery.blade.php ENDPATH**/ ?>